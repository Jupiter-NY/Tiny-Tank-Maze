# Tiny Tank Maze v5.23 — Audited Anti-Cheat

v5.23 keeps the anti-AI/static-obfuscation approach from v5.22 and adds a
server-validated gameplay audit intended to reject plausible-looking scores
earned with common client cheats.

## Main protections

- different randomized static obfuscation scheme on every build
- hundreds of local variables/functions/parameters renamed
- most ordinary strings encoded
- production comments removed
- deliberate legacy-name decoys for common regex patchers
- no source maps
- no Web Worker
- no eval()/Function() source execution
- CSP blocks inline/blob-script execution
- SRI pins game.html to the exact generated game.js
- production-host / blob boot checks
- frequent server gameplay audits
- existing v5.19 score/rate/run-token validation retained

## Gameplay audit checks

The server now checks, among other things:

- player speed / teleport distance
- wall overlap and wall-crossing paths
- player HP conservation
- healing bounds
- max HP vs permanent upgrades
- enemy movement / teleport distance
- enemies inside walls
- enemy max HP vs wave scaling
- enemy HP edits that did not come from audited damage
- player bullet speed
- player direct bullet damage
- oversized single damage events
- direct player-bullet paths through walls
- enemy bullet events and predicted player hits for non-bouncing shots
- deleted enemy bullets when the server predicts they should have hit
- fresh gameplay-audit packets before final leaderboard submission

## Important limitation

This is much stronger against the casual DevTools + AI workflow, but it is
still not a fully authoritative single-player server. A sufficiently capable
attacker who reverse-engineers and forges the audit protocol may still bypass
some checks. Full deterministic server replay would be the next major step.

## Build

Keep the readable source private:

`private-source/game.source.js`

Install once:

```sh
npm install
```

After editing:

```sh
npm run build
npm run verify
```

Optional adversarial tests:

```sh
npm run pentest
```

Deploy only the public files you actually need from `production/`.
Do not publish `private-source/`, `tools/`, or source maps.
