import assert from 'node:assert/strict';
import { createAuditState, validateAuditPacket } from './secure-game-audit.js';

function openMazeCode(withWall=false) {
  const COLS=18, ROWS=12;
  const cells=[];
  for(let r=0;r<ROWS;r++){
    for(let c=0;c<COLS;c++){
      const w=[r===0,c===COLS-1,r===ROWS-1,c===0];
      cells.push(w);
    }
  }
  if(withWall){
    // Wall between cells (1,1) and (2,1).
    cells[1*COLS+1][1]=true;
    cells[1*COLS+2][3]=true;
  }
  return cells.map(w => (w[0]?1:0)|(w[1]?2:0)|(w[2]?4:0)|(w[3]?8:0)).map(n=>n.toString(16)).join('');
}
const mods0={rapid:0,velocity:0,explosive:0,ricochet:0,damage:0,maxhp:0,regen:0,multishot:0,poison:0,bounceblast:0};
function basePacket({seq=1,maze=openMazeCode(),trail,expectedDamageTotal=0,healingTotal=0,enemies=[],enemyDamage=[],enemyShots=[],playerHits=[],maxPlayerBulletSpeedSeen=470,maxPlayerBulletDamageSeen=30,maxSingleEnemyDamageSeen=30}={}){
  const t=trail.at(-1)[0];
  return {build:'5.23.0',seq,elapsedMs:t,wave:1,maze,mods:mods0,trail,expectedDamageTotal,healingTotal,enemies,enemyDamage,enemyShots,playerHits,maxPlayerBulletSpeedSeen,maxPlayerBulletDamageSeen,maxSingleEnemyDamageSeen};
}

// Legit movement and enemy state.
{
  const s=createAuditState();
  const p=basePacket({trail:[[0,1,96,96,100,100],[100,1,110,96,100,100],[200,1,125,96,100,100]],enemies:[[1,1,400,400,60,60,true,false]],enemyDamage:[[1,0]]});
  assert.doesNotThrow(()=>validateAuditPacket(s,p,'classic'));
}

// Speedhack.
{
  const s=createAuditState();
  const p=basePacket({trail:[[0,1,96,96,100,100],[100,1,160,96,100,100]]});
  assert.throws(()=>validateAuditPacket(s,p,'classic'), e=>e.code==='AUDIT_PLAYER_SPEED');
}

// Noclip through an internal wall.
{
  const s=createAuditState();
  const maze=openMazeCode(true);
  const p=basePacket({maze,trail:[[0,1,96,96,100,100],[400,1,150,96,100,100]]});
  assert.throws(()=>validateAuditPacket(s,p,'classic'), e=>['AUDIT_PLAYER_WALL_CROSS','AUDIT_PLAYER_IN_WALL'].includes(e.code));
}

// Invulnerability / HP reset: audited 20 damage but HP still 100.
{
  const s=createAuditState();
  const p=basePacket({trail:[[0,1,96,96,100,100],[200,1,110,96,100,100]],expectedDamageTotal:20});
  assert.throws(()=>validateAuditPacket(s,p,'classic'), e=>e.code==='AUDIT_HP_MISMATCH');
}

// Deleted enemy bullet: server predicts a hit but client reports zero expected damage.
{
  const s=createAuditState();
  const shot=[1,0,1,40,96,390,0,20,4,0,0,0,2.2];
  const p=basePacket({trail:[[0,1,120,96,100,100],[100,1,120,96,100,100],[200,1,120,96,100,100],[300,1,120,96,100,100]],enemyShots:[shot]});
  assert.throws(()=>validateAuditPacket(s,p,'classic'), e=>e.code==='AUDIT_MISSING_DAMAGE');
}

// Same enemy bullet with legitimate damage bookkeeping + HP loss passes.
{
  const s=createAuditState();
  const shot=[1,0,1,40,96,390,0,20,4,0,0,0,2.2];
  const p=basePacket({trail:[[0,1,120,96,100,100],[100,1,120,96,100,100],[200,1,120,96,100,100],[300,1,120,96,80,100]],enemyShots:[shot],expectedDamageTotal:20});
  assert.doesNotThrow(()=>validateAuditPacket(s,p,'classic'));
}

// Enemy teleport between packets.
{
  const s=createAuditState();
  const p1=basePacket({trail:[[0,1,96,96,100,100],[1000,1,110,96,100,100]],enemies:[[1,1,300,300,60,60,true,false]],enemyDamage:[[1,0]]});
  validateAuditPacket(s,p1,'classic');
  const p2=basePacket({seq:2,maze:'',trail:[[1100,1,112,96,100,100],[1200,1,114,96,100,100]],enemies:[[1,1,700,300,60,60,true,false]],enemyDamage:[[1,0]]});
  assert.throws(()=>validateAuditPacket(s,p2,'classic'), e=>e.code==='AUDIT_ENEMY_TELEPORT');
}

// Enemy HP edit without audited damage.
{
  const s=createAuditState();
  const p=basePacket({trail:[[0,1,96,96,100,100],[200,1,110,96,100,100]],enemies:[[1,1,300,300,1,60,true,false]],enemyDamage:[[1,0]]});
  assert.throws(()=>validateAuditPacket(s,p,'classic'), e=>e.code==='AUDIT_ENEMY_HP_EDIT');
}

// Player bullet damage manipulation.
{
  const s=createAuditState();
  const p=basePacket({trail:[[0,1,96,96,100,100],[200,1,110,96,100,100]],maxPlayerBulletDamageSeen:300,maxSingleEnemyDamageSeen:300});
  assert.throws(()=>validateAuditPacket(s,p,'classic'), e=>['AUDIT_PLAYER_BULLET_DAMAGE','AUDIT_DAMAGE_SPIKE'].includes(e.code));
}

// Player bullet path through wall: spawn left of wall, claimed hit right of wall without bounces.
{
  const s=createAuditState();
  const maze=openMazeCode(true);
  const hit=[300,0,1,96,96,470,0,0,4,220,96,30];
  const p=basePacket({maze,trail:[[0,1,96,160,100,100],[100,1,100,160,100,100],[200,1,104,160,100,100],[300,1,108,160,100,100]],playerHits:[hit]});
  assert.throws(()=>validateAuditPacket(s,p,'classic'), e=>e.code==='AUDIT_PLAYER_BULLET_WALL');
}

console.log('secure gameplay audit tests passed');
