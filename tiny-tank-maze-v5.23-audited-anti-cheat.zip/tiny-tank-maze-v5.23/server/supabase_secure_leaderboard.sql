-- Tiny Tank Maze v5.19 secure leaderboard write policy
-- Run this in Supabase SQL Editor AFTER deploying the secure game-server route.
--
-- Browsers keep SELECT access for displaying the leaderboard.
-- Browsers lose INSERT/UPDATE/DELETE access, so copying the old REST request
-- can no longer create a score.

alter table public.leaderboard enable row level security;

revoke insert, update, delete
  on table public.leaderboard
  from anon, authenticated;

grant select
  on table public.leaderboard
  to anon, authenticated;

-- The server's Supabase secret key maps to service_role and bypasses RLS.
-- Keep normal service_role table access available.
grant select, insert
  on table public.leaderboard
  to service_role;

-- Existing browser INSERT policies may remain in the database, but the revoked
-- table grant above prevents anon/authenticated from reaching INSERT at all.
-- You can also delete the old "Public can submit leaderboard scores" policy in
-- the Supabase dashboard after confirming the server route is live.
