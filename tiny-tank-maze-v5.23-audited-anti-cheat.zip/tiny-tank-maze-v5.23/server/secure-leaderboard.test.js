import assert from "node:assert/strict";
import {
  bossBonusBeforeWave,
  createRunToken,
  enemiesInWave,
  killsBeforeWave,
  pointsBounds,
  validateFinalScore,
  validateProgress,
  verifyRunToken,
  waveBonusBeforeWave,
} from "./secure-leaderboard-core.js";

assert.equal(enemiesInWave(1), 6);
assert.equal(enemiesInWave(10), 1);
assert.equal(enemiesInWave(15), 1);
assert.equal(killsBeforeWave(2), 6);
assert.equal(waveBonusBeforeWave(3), 1500);
assert.equal(bossBonusBeforeWave(11), 3250);

const wave10Kills = killsBeforeWave(10);
const wave10Bounds = pointsBounds("infinite", 10, wave10Kills);

assert.doesNotThrow(() =>
  validateProgress({
    mode: "infinite",
    wave: 10,
    kills: wave10Kills,
    points: wave10Bounds.min,
    elapsedMs: Math.max(60_000, wave10Kills * 250),
  })
);

assert.throws(() =>
  validateProgress({
    mode: "infinite",
    wave: 10,
    kills: 2,
    points: 200,
    elapsedMs: 60_000,
  })
);

assert.throws(() =>
  validateProgress({
    mode: "infinite",
    wave: 2,
    kills: 999,
    points: 100_000,
    elapsedMs: 60_000,
  })
);

assert.doesNotThrow(() =>
  validateFinalScore({
    mode: "classic",
    wave: 1,
    kills: 6,
    points: 2100,
    score: 2100 + 750 + 200 + 460,
    hp: 100,
    elapsedMs: 5000,
    cleared: true,
  })
);

assert.throws(() =>
  validateFinalScore({
    mode: "classic",
    wave: 1,
    kills: 6,
    points: 2100,
    score: 99_999,
    hp: 100,
    elapsedMs: 5000,
    cleared: true,
  })
);

const secret = "this-is-a-test-secret-that-is-definitely-over-32-bytes";
const issued = createRunToken("infinite", secret, 60_000);
const payload = verifyRunToken(issued.token, secret);

assert.equal(payload.rid, issued.runId);
assert.equal(payload.mode, "infinite");
assert.throws(() => verifyRunToken(`${issued.token}x`, secret));

console.log("secure leaderboard validation tests passed");
