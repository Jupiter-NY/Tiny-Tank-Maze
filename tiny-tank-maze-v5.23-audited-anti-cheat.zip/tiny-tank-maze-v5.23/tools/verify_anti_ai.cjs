const fs = require('fs');
const path = require('path');
const vm = require('vm');
const cp = require('child_process');
const crypto = require('crypto');
let ts;
try { ts = require('typescript'); } catch { console.error('TypeScript is required. Run: npm install'); process.exit(1); }

const ROOT = path.resolve(__dirname, '..');
const file = path.join(ROOT, 'production', 'game.js');
const htmlFile = path.join(ROOT, 'production', 'game.html');
const code = fs.readFileSync(file, 'utf8');
const html = fs.readFileSync(htmlFile, 'utf8');

for (const bad of ['eval(', 'new Function', 'sourceMappingURL']) {
  if (code.includes(bad)) throw new Error(`Forbidden construct found: ${bad}`);
}

const scanner = ts.createScanner(ts.ScriptTarget.Latest, false, ts.LanguageVariant.Standard, code);
let comments = 0;
while (true) {
  const token = scanner.scan();
  if (token === ts.SyntaxKind.EndOfFileToken) break;
  if (token === ts.SyntaxKind.SingleLineCommentTrivia || token === ts.SyntaxKind.MultiLineCommentTrivia) comments++;
}
if (comments !== 0) throw new Error(`Production game.js still has ${comments} comments`);

const weird = code.match(/_q\$[a-z0-9]{8,16}/g) || [];
if (new Set(weird).size < 400) throw new Error('Not enough renamed/obfuscated identifiers detected');

const baitPatterns = [
  /function updatePlayer\s*\(\s*dt\s*\)\s*\{/,
  /function damageTank\s*\(\s*tank\s*,\s*amount\s*,\s*attacker\s*\)\s*\{/,
  /function isVisibleToPlayer\s*\([^)]*\)\s*\{/,
  /function drawFog\s*\(\s*\)\s*\{/,
  /function explodeGrenade\s*\([^)]*\)\s*\{/
];
for (const rx of baitPatterns) if (!rx.test(code)) throw new Error(`Expected bait function missing: ${rx}`);

// Reproduce the previously observed source-rewrite attack. It should only patch decoys.
let patched = code;
const patches = [
  [/function updatePlayer\s*\(\s*dt\s*\)\s*\{/, 'player.speed = 330;'],
  [/function damageTank\s*\(\s*tank\s*,\s*amount\s*,\s*attacker\s*\)\s*\{/, 'if (tank === player) { tank.hp = tank.maxHp; return; }'],
  [/function isVisibleToPlayer\s*\([^)]*\)\s*\{/, 'return true;'],
  [/function drawFog\s*\(\s*\)\s*\{/, 'return;']
];
for (const [pattern, addition] of patches) {
  if (!pattern.test(patched)) throw new Error(`Known patch no longer lands on bait: ${pattern}`);
  patched = patched.replace(pattern, m => m + '\n' + addition);
}
new vm.Script(patched);

// CSP and SRI checks.
if (!/Content-Security-Policy/.test(html)) throw new Error('game.html is missing CSP');
if (!/script-src 'self'/.test(html)) throw new Error('CSP is missing strict script-src self');
if (/script-src[^;]*(?:unsafe-inline|unsafe-eval|blob:|data:)/.test(html)) throw new Error('script-src contains a dangerous allowance');
const sri = 'sha384-' + crypto.createHash('sha384').update(code, 'utf8').digest('base64');
if (!html.includes(`integrity="${sri}"`)) throw new Error('game.html SRI does not match production game.js');

cp.execFileSync(process.execPath, [path.join(__dirname, 'smoke_runtime.cjs'), file], { stdio: 'inherit' });
cp.execFileSync(process.execPath, [path.join(ROOT, 'server', 'secure-game-audit.test.js')], { stdio: 'inherit' });
cp.execFileSync(process.execPath, [path.join(ROOT, 'server', 'anti-cheat-pentest.test.js')], { stdio: 'inherit' });
cp.execFileSync(process.execPath, [path.join(ROOT, 'server', 'secure-leaderboard.test.js')], { stdio: 'inherit' });

console.log('VERIFY_OK');
console.log(`Unique weird identifiers: ${new Set(weird).size}`);
console.log('Comments: 0');
console.log('CSP: strict script-src self');
console.log('SRI: matches game.js');
console.log('Known regex cheat lands on decoys, not the real implementation.');
console.log('Gameplay audit adversarial tests: passed.');
