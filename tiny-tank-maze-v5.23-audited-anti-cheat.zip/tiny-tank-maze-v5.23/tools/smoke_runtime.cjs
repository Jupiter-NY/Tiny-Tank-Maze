const fs=require('fs'), vm=require('vm');
const path=require("path");
const target=process.argv[2] || path.resolve(__dirname,"..","production","game.js");
const code=fs.readFileSync(target,'utf8');
class HTMLElement{}; class HTMLInputElement extends HTMLElement{}; class HTMLTextAreaElement extends HTMLElement{}; class HTMLSelectElement extends HTMLElement{};
class CanvasRenderingContext2D{}
for(const n of ['save','restore','beginPath','moveTo','lineTo','closePath','clip','clearRect','fillRect','strokeRect','drawImage','arc','fill','stroke','fillText','setTransform','translate','rotate','scale','strokeText','setLineDash']) CanvasRenderingContext2D.prototype[n]=function(){};
CanvasRenderingContext2D.prototype.createRadialGradient=function(){return {addColorStop(){}}};
CanvasRenderingContext2D.prototype.createLinearGradient=function(){return {addColorStop(){}}};
CanvasRenderingContext2D.prototype.measureText=function(){return {width:10}};
const ctx=new CanvasRenderingContext2D();
function makeClassList(){return {add(){},remove(){},contains(){return true},toggle(){}}}
function element(id=''){
  const obj=new HTMLElement();
  Object.assign(obj,{id,width:960,height:640,value:'',textContent:'',innerHTML:'',disabled:false,hidden:false,isContentEditable:false,classList:makeClassList(),style:{},dataset:{},children:[],appendChild(){},remove(){},setAttribute(){},removeAttribute(){},focus(){},addEventListener(){},removeEventListener(){},closest(){return element('closest')},getBoundingClientRect(){return {left:0,top:0,width:960,height:640}},getContext(){return ctx},querySelector(){return element()},querySelectorAll(){return []}});
  return obj;
}
const els=new Map();
const document={
  hidden:false, documentElement:element('html'), head:element('head'), body:element('body'), currentScript:{src:'http://localhost/game.js'},
  getElementById(id){if(!els.has(id)) els.set(id,element(id)); return els.get(id)},
  createElement(tag){const e=element(tag); if(tag==='canvas'){e.width=960;e.height=640;} return e},
  addEventListener(){},querySelector(){return element()},querySelectorAll(){return []}
};
const storage=new Map();
const localStorage={getItem(k){return storage.get(k)??null},setItem(k,v){storage.set(k,String(v))},removeItem(k){storage.delete(k)}};
const sandbox={
  console, document, localStorage,
  HTMLElement,HTMLInputElement,HTMLTextAreaElement,HTMLSelectElement,CanvasRenderingContext2D,
  window:null, self:null, globalThis:null,
  location:{search:'?mode=classic',hostname:'localhost',protocol:'http:',origin:'http://localhost',href:'http://localhost/game.html?mode=classic'},
  performance:{now(){return 1000}}, requestAnimationFrame(){return 1}, cancelAnimationFrame(){},
  setTimeout(fn){return 1},clearTimeout(){},setInterval(){return 1},clearInterval(){},
  URL,URLSearchParams,TextDecoder,TextEncoder,Uint8Array,Array,Object,Math,String,Number,Boolean,Date,JSON,Promise,Map,Set,WeakMap,WeakSet,RegExp,Error,TypeError,
  atob(s){return Buffer.from(s,'base64').toString('binary')}, btoa(s){return Buffer.from(s,'binary').toString('base64')},
  crypto:require('crypto').webcrypto,
  fetch:async()=>({ok:true,status:200,text:async()=> '[]',json:async()=>[]}),
  ResizeObserver:class{observe(){}disconnect(){}},MutationObserver:class{observe(){}disconnect(){}},
  Image:class{}, Audio:class{},
};
sandbox.window=sandbox; sandbox.self=sandbox; sandbox.globalThis=sandbox;
sandbox.window.addEventListener=()=>{}; sandbox.window.removeEventListener=()=>{};
sandbox.window.TankLeaderboard={canSubmitSecurely(){return false},isConfigured(){return false}};
vm.createContext(sandbox);
try{vm.runInContext(code,sandbox,{timeout:5000,filename:'game.js'}); console.log('SMOKE_OK')}catch(e){console.error('SMOKE_FAIL',e.stack);process.exit(1)}
