// LOCAL TEMPLATE ONLY — keep your already-configured production config.js on GitHub.
window.TANK_CONFIG = {
  // Optional Supabase settings for the global leaderboard.
  // Leave blank for local-only testing.
  supabaseUrl: "",
  supabasePublishableKey: "",

  // Optional multiplayer WebSocket server, e.g.
  // "wss://your-server.example.com/ws"
  // Leave blank if you only want to test Classic/Infinite locally.
  multiplayerServer: "",

  // Optional override for secure score submission.
  // If blank, the game derives this from multiplayerServer
  // (wss://server.example/ws -> https://server.example).
  leaderboardApiUrl: "",
};
