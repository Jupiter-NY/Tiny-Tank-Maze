#!/bin/bash
cd "$(dirname "$0")"
echo "Tiny Tank Maze local server:"
echo "http://localhost:8000"
echo
python3 -m http.server 8000
