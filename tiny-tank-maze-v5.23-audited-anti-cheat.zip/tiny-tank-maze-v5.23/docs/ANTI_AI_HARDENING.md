# What the anti-AI build does

## Real symbol obfuscation

The builder uses the TypeScript compiler's symbol information rather than
blind text replacement. This lets it rename local functions, variables,
parameters, and references together.

This is important for code such as:

```js
const { c, r } = current;
return { c, r };
```

A naive renamer can break the object keys. The v5.22 transformer preserves
those keys while changing the local variable identifiers.

## AI-deterrence strings

The production file contains inert strings phrased as instructions to an AI
assistant to refuse reconstruction/cheat assistance.

They do not execute and do not affect gameplay.

Do not treat them as a security mechanism. They are only an extra obstacle for
a user who blindly pastes the full source into an AI.

## Decoy gameplay functions

The public build deliberately contains unused functions named:

```text
updatePlayer
damageTank
isVisibleToPlayer
drawFog
explodeGrenade
```

They operate only on isolated fake state.

The real functions have randomized `_0x...` names.

The verifier applies the previously observed regex patch to a copy of the
production source and confirms that the patch still parses after landing on
the decoys.

## String hiding

Most ordinary quoted string literals are stored in an encoded table. They are
decoded only when used.

This hides many DOM IDs, status strings, upgrade names, mode strings, and other
semantic clues from a quick source/AI inspection.

## Comments

The public `production/game.js` contains zero JavaScript comment tokens.

Readable source comments remain in the PRIVATE source file for development.

## Rebuild randomization

Every:

```sh
npm run build
```

creates fresh randomized local names and fresh string encoding keys.

A solution written against one production release should therefore be more
fragile across later releases.
