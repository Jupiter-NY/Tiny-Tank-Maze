# Remaining recommended protections

## 1. CSP

Your web host should send a Content-Security-Policy similar to:

```text
default-src 'self';
script-src 'self';
connect-src 'self'
  https://YOUR_SUPABASE_PROJECT.supabase.co
  https://YOUR_GAME_SERVER
  wss://YOUR_GAME_SERVER;
img-src 'self' data:;
style-src 'self' 'unsafe-inline';
object-src 'none';
base-uri 'none';
frame-ancestors 'none';
```

Do not add these to `script-src`:

```text
'unsafe-inline'
'unsafe-eval'
blob:
data:
```

v5.22 does not need `unsafe-eval`.

If your host cannot set HTTP headers, a CSP `<meta http-equiv=...>` near the
top of `<head>` can still provide useful script restrictions, although an HTTP
header is preferable.

## 2. Keep readable source private

Only publish `production/`.

Do not publish:
- `private-source/`
- build tools if your public repository exposes them alongside readable source
- source maps
- old readable copies of `game.js`

## 3. Server score validation

The existing v5.19 secure-score modules are retained under `server/`.

Add these beside your CURRENT server.js:

```text
secure-leaderboard.js
secure-leaderboard-core.js
```

Then import/mount the router as previously described.

Keep these only on the server:

```text
SUPABASE_SECRET_KEY
LEADERBOARD_HMAC_SECRET
```

## 4. Supabase write lockdown

After secure server submission is working, run:

```text
server/supabase_secure_leaderboard.sql
```

The browser should be able to read leaderboard rows but not insert them
directly.
