# Deploying v5.23

## Website branch

For the anti-cheat upgrade, update at least:

```text
game.js
game.html
leaderboard.js
```

Recommended as well, because v5.23 added the same CSP meta policy:

```text
index.html
multiplayer.html
```

Keep your existing production `config.js` with the real values. Do not replace
it with the blank local template from this ZIP.

Your production config should still contain your public values, for example:

```js
window.TANK_CONFIG = {
  supabaseUrl: "https://iwugissyviygmlelemfs.supabase.co",
  supabasePublishableKey: "YOUR_PUBLIC_KEY",
  multiplayerServer: "wss://tiny-tank-maze.onrender.com/ws",
  leaderboardApiUrl: "https://tiny-tank-maze.onrender.com",
};
```

Never put `sb_secret_...` or `LEADERBOARD_HMAC_SECRET` in frontend files.

## Server branch

v5.23's secure leaderboard router now depends on a new file.

In the same folder as your current server entry file, deploy/update:

```text
secure-leaderboard.js       <-- updated
secure-game-audit.js        <-- NEW
secure-leaderboard-core.js  <-- keep/update from package
```

Your existing server entry only needs the same router mount used by v5.19:

```js
import { createSecureLeaderboardRouter } from "./secure-leaderboard.js";

app.use(express.json());

app.use(
  "/api/leaderboard",
  createSecureLeaderboardRouter({ allowedOrigins })
);
```

If that is already present, you do not add a second copy.

## Render environment

Keep:

```text
SUPABASE_URL=https://iwugissyviygmlelemfs.supabase.co
SUPABASE_SECRET_KEY=sb_secret_...
LEADERBOARD_HMAC_SECRET=<your random secret>
ALLOWED_ORIGINS=https://littletinygames.com,https://www.littletinygames.com
```

## Safe deployment order

A practical order is:

1. Push the v5.23 frontend files.
2. Confirm the game loads.
3. Push `secure-leaderboard.js` + `secure-game-audit.js` to the server branch.
4. Let Render redeploy.
5. Start a new run and check Network for:
   - `/api/leaderboard/run/start`
   - `/api/leaderboard/run/audit`
   - `/api/leaderboard/run/checkpoint`
   - `/api/leaderboard/run/finish`
6. Play a legitimate Classic game and confirm the score submits.
7. Keep the Supabase browser INSERT lockdown enabled.

Old runs that started before a server redeploy may become invalid. Start a new
run after deployment when testing.

## CSP

`game.html`, `index.html`, and `multiplayer.html` contain this policy shape:

```text
default-src 'self';
script-src 'self';
connect-src 'self'
  https://iwugissyviygmlelemfs.supabase.co
  https://tiny-tank-maze.onrender.com
  wss://tiny-tank-maze.onrender.com;
img-src 'self' data:;
style-src 'self' 'unsafe-inline';
object-src 'none';
base-uri 'none';
worker-src 'none';
```

Do not add `unsafe-inline`, `unsafe-eval`, `blob:`, or `data:` to `script-src`.

## SRI

The build script automatically recalculates the SHA-384 integrity value for
`game.js` and writes it into `game.html`.

Therefore, after modifying the readable game source, always run:

```sh
npm run build
```

before uploading both `game.js` and `game.html`.
