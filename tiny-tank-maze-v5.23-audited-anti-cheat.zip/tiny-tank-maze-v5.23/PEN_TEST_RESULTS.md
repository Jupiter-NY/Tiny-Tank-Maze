# v5.23 Defensive Pen-Test Results

These tests deliberately use plausible Classic final statistics that pass the
old mathematical score validator. The attack is rejected only because of the
new gameplay audit.

| Attempted cheat | Old behavior | v5.23 result |
| --- | --- | --- |
| player speed / teleport | Old score-only validator could accept plausible final stats | `AUDIT_PLAYER_SPEED` |
| noclip through wall | Old score-only validator could accept plausible final stats | `AUDIT_PLAYER_WALL_CROSS` |
| invulnerability / HP reset | Old score-only validator could accept plausible final stats | `AUDIT_HP_MISMATCH` |
| delete enemy bullets | Old score-only validator could accept plausible final stats | `AUDIT_MISSING_DAMAGE` |
| boost player bullet damage | Old score-only validator could accept plausible final stats | `AUDIT_PLAYER_BULLET_DAMAGE` |
| enemy teleport / group-to-center | Old score-only validator could accept plausible final stats | `AUDIT_ENEMY_TELEPORT` |
| direct enemy HP edit | Old score-only validator could accept plausible final stats | `AUDIT_ENEMY_HP_EDIT` |
| shoot through wall | Old score-only validator could accept plausible final stats | `AUDIT_PLAYER_BULLET_WALL` |

## What was exercised

The test suite includes:

- player speed/teleport manipulation
- player wall noclip
- HP reset / invulnerability
- deleting an enemy projectile that the server predicts should hit
- boosted player bullet damage
- teleporting/grouping an existing enemy
- directly editing enemy HP
- claiming a player-bullet hit through a wall

The normal audit test suite also contains legitimate control cases to ensure
ordinary state transitions are accepted.

## Remaining gaps

v5.23 is not fully server-authoritative.

Notably:

- bouncing enemy bullets are not used as mandatory-hit evidence, to reduce false
  positives
- the server does not independently simulate all enemy AI decisions
- pickup existence is not fully authoritative
- a sophisticated attacker who understands and forges the audit telemetry could
  still attempt to mimic legitimate state
- a fully deterministic server replay would be stronger

The goal of v5.23 is to reject the high-value, casual client manipulations that
previously produced plausible leaderboard scores.
